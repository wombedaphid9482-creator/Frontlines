# Project Faction: Frontlines

**Frontlines v0.7.0 — Onboarding, Action Economy & Frontline Rules.**

Fight for territory. Commit Presence. Push the frontline into enemy ground.

Start with **Learn Frontlines**, an eleven-lesson playable operation that teaches what to do and why. The central menu keeps **Play**, **Tutorial**, **Arsenal**, **War Room** and **Settings** easy to find. Major screens fit the window; card collections, logs, decks and reports scroll inside contained panels.

## Launch

Double-click **Launch Frontlines.cmd**, or open **index.html** in a current desktop browser. All artwork, rules and interface assets are local. No account, internet connection or server is required.

Optional local preview with Node 18 or newer:

```text
npm start
```

Open `http://127.0.0.1:4173`. The server binds only to this computer. Native development launch uses `npm run electron` with the installed dependencies.

The locally built [v0.7.0 Windows installer](release/0.7.0/Frontlines-Setup-0.7.0.exe) and [unpacked application](release/0.7.0/win-unpacked/Frontlines.exe) are ready for playtesting. Keep the entire unpacked folder together. See [the release guide](docs/RELEASE-0.7.0.md) and [manifest](docs/release-0.7.0-manifest.json) for exact hashes, validation and manual checks. The installer is unsigned; no publication or installation over the owner's copy occurred.

## Learn and play

1. Choose **Learn Frontlines** at first launch, or **Tutorial** from the command menu. You can skip and return later.
2. Perform real deployments, movement, combat, capture, retreat and Orders. Highlights, short objectives and progressive hints explain the purpose of each interaction.
3. Complete a short operation against Learning AI, then choose **Play** for an ordinary match.
4. Select faction, actual starter/preset/saved deck and AI difficulty. **Easy — Learning** is intended for first matches; Normal, Hard and Expert improve tactical decision quality without hidden resource or stat bonuses.
5. Inspect costs and legal targets, build Presence on the orange objective, and end your offensive turn to earn capture progress. Push toward enemy home to win.

Tutorial supports Restart lesson, Restart tutorial, Skip, Continue and Replay. Local progress resumes at the current lesson boundary. Known hands and declared shortened scenarios make the first encounters predictable; the final training lesson is an actual legal match. Tutorial scenarios are identified separately from competitive evidence.

The contained **Field Manual** explains winning, turns, Capacity, Command Actions, deployment, combat, territory, frontline, retreat, card types, keywords and factions. Dismissible contextual tips remain available afterward, with disable/reset controls in Settings.

## Capacity and Command Actions

```text
Available Capacity = total Capacity − committed Presence − temporary spending
```

Default Capacity starts at 20, grows by 10 on later own offensive turns and caps at 80. Deployed cards keep their printed Presence committed. Destruction or recall frees it. Orders spend Presence temporarily until their owner's next offensive turn.

Each offensive turn still has **three Command Actions**, now reserved for major battlefield decisions.

| Action | Command Actions |
| --- | ---: |
| Ordinary troop deployment; healing/draw/reclaim support Orders | 0 |
| Move or initiate an attack | 1 |
| Leaders; explicitly marked Heavy units/command assets; tactical damage/Rally/disruption/Sabotage Orders | 1 |
| Responses, counters, Guard, forced retreat and Breakthrough | 0 |

Every card shows its explicit cost. Zero-command deployment remains possible after all three commands are spent if Capacity, timing, owned territory and slots permit. Free Action means free of command spending; it still requires Capacity. [Sprint 6 rules](docs/SPRINT-006.md) list every major deployment and exact legality.

New units may move but normally cannot attack on their deployment turn without Rush. Movement normally exhausts; Mobile preserves readiness on the first move while still consuming a command. Same-territory combat deals damage simultaneously after defender response and optional counter. Wounds persist and dead cards enter discard. Empty reserves recycle discard; there is no fatigue damage.

## Territory and forced retreat

The battlefield has seven connected territories, each with five friendly permanent-card positions by default. The orange objective begins at neutral Downtown. At offensive turn end, your surviving objective forces add printed Presence to capture progress, even with defenders present. Default threshold is 25.

On capture, surviving enemy units immediately retreat one adjacent territory toward their own home, into friendly-owned ground with a free slot. Retreat positions resolve in stable numeric UID order. Immobile assets and units without a legal retreat are eliminated, releasing commitment. Enemies never remain stranded behind the new frontline.

After defender resolution, the objective advances and your movable survivors make the existing adjacent Breakthrough, preserving wounds/readiness. Friendly assets and overflow can remain on your owned ground. Capture enemy home or the configured territory requirement to win; gameplay locks and rematch starts a fresh match.

## Difficulty, settings and desktop controls

**Easy — Learning** uses readable local choices. **Normal — Standard** makes competent tactical decisions. **Hard — Tactical** adds deck priorities and bounded two-action sequencing. **Expert — Command AI** adds stronger deck-aware three-action planning for experienced players. AI uses the same cards, Capacity and legal actions as the human. It does not inspect opponent hands or deck order.

Settings remembers difficulty for future matches, **Fast / Normal / Deliberate** AI cadence, contextual hints and optional AI explanations. Current opponents retain their match-start difficulty. Normal/Fast combat animation, reduced effects/shake, muted-by-default sound and volume remain available. System reduced motion is respected.

The Windows app uses true Electron fullscreen through **F11**, **Alt+Enter** or Settings → Display. It remembers display mode and normal bounds and recovers inaccessible monitor placement. Escape closes inspection/overlays or returns to commands; it does not quit or toggle native fullscreen.

Menu/About versions derive from actual package/build metadata. Installed update feedback shows available/downloading/ready state and **Later / Restart & update**. A downloaded update never forces a restart or installs during an active match. Plain browser launch does not install desktop updates.

## Arsenal and custom decks

All **80 gameplay cards** are available for testing. Each faction retains a 26-card starter and two archetype presets. Save, name, duplicate, edit, delete with confirmation, and import/export custom decks locally.

Deck construction uses exactly 26 cards from one faction, at most four copies of an ordinary card and two copies of a Leader. A Unique deployed card still allows only one active copy. Illegal or outdated drafts remain saved with explained warnings instead of being silently deleted.

Arsenal uses a contained collection, deck contents and card briefing, with a persistent composition summary and **Save / Test in War Room / Duplicate / Export / Play** actions. Inspect artwork, rules and costs; filter/sort; examine Presence and type distribution. **Ctrl+S** saves; unsaved edits prompt before leaving. Saved decks become the actual match and simulation inventories.

See [deckbuilding](docs/DECKBUILDING.md), [card design/counterplay](docs/arsenal/CARD-DESIGN.md), and [keywords](docs/KEYWORDS.md). Native/browser/direct-file storage origins differ; exchange deck JSON when moving between them.

## War Room and simulation policy

**War Room stays accessible inside the game for player deck testing.** Open it from the central menu, Arsenal's Test command, **Launch Simulator.cmd** or `simulator.html`. No admin access is required.

Quick Matchup, Tournament, Faction Overview and Advanced Lab provide saved-deck selection, exact requested counts, paired seats, fixed Run/Pause/Resume/Stop commands and bounded results. Advanced retains seeds, explicit profiles/policies, rule overrides, confidence intervals, diagnostics, replay, comparisons and JSON/HTML/CSV export. Live rules and saved decks are not changed by an experiment.

AI-versus-AI uses the same authoritative engine without battlefield animation. HTTP launch uses a worker; direct offline launch yields cooperatively to keep controls responsive. Reports snapshot rules, command costs and deck lists, identify originating game version and keep errors/cutoffs separate from victories. Incompatible replay versions are refused. Free-play, command-spending and forced-retreat/elimination metrics join existing economy/territory statistics.

**Ryken runs balance simulations unless explicitly authorizing Codex to run them.** No Sprint 6 balance campaign or card-stat tuning was performed. The earlier Sprint 5 competitive gate was not completed; its failing older-rule baseline is historical evidence, not a new-rule result. The standing target remains 45–55% cross-faction rates and preferred spread ≤5 percentage points, with archetypes and extreme matchups reviewed separately.

The exact first owner-operated 10,000-game request is in [SPRINT-006.md](docs/SPRINT-006.md). A 50,000-game confirmation requires subsequent owner review/authorization. See the [War Room guide](docs/SIMULATOR.md), [game roadmap](docs/GAME-ROADMAP.md), [simulator roadmap](docs/SIMULATOR-ROADMAP.md) and [balance history](docs/BALANCE.md).

## Verification and known limits

```text
npm test
```

Final checkpoint: **177/177 Node tests passed**, with **35 new tests**, and six browser suites passed. All eleven tutorial lessons completed through real UI clicks and an actual Learning-AI victory; ordinary matches, saved decks, War Room parity, five desktop sizes and emulated display scaling passed. Packaged native shell/game/Arsenal/War Room checks passed, including actual fullscreen shortcuts and tutorial deployment. The [release guide](docs/RELEASE-0.7.0.md) records the scope and limits. These are automated checks; a new human completing the tutorial and an Easy match remains essential.

The final payload matches 58 frozen source/runtime files; all 31 historical baseline hashes are unchanged. [The entry source checkpoint](docs/checkpoints/sprint6-entry-a7921c0.zip) preserves the pre-sprint state. [Tutorial](docs/screenshots/tutorial-sprint-6.png) and [battlefield](docs/screenshots/battlefield-sprint-6.png) screenshots show the final interface.

Do not use `npm run playtest`, simulation CLI batches or targeted experiment scripts as an autonomous balance loop. They are owner-operated analysis tools. Ordinary unit/browser/tutorial/small rule-smoke tests remain expected.

Five optimized faction atlases provide coherent representative portraits for the 80 cards. Signature bespoke art, final audio and competitive tuning remain future work. No online matchmaking, accounts, packs, monetization, sixth faction or campaign progression is added.

## Main modules

| Module | Responsibility |
| --- | --- |
| `engine.js` | Authoritative transitions, legality/cost API, combat, Capacity, capture, retreat, victory and invariants. |
| `balance.js`, `balance/`, `live-runtime.js` | Explicit isolated rules/card profiles; Sprint 6 current default and historical profiles. |
| `app.js`, `command.css`, `effects.*` | Central commands, bounded battlefield/hand, cost/target feedback, history, privacy and presentation. |
| `tutorial.js`, `tutorial.css`, `field-manual.js` | Conserved lesson fixtures, guided controller, progressive hints, progress and concise rules reference. |
| `ai.js` | Public-information policy evaluation, selectable fair difficulty and bounded planning. |
| `decks.js`, `deck-builder.*` | Legal construction, persistence, presets, inspection and Arsenal. |
| `sim-core.js`, `telemetry.js`, `analytics.js`, `simulator-*` | War Room, deterministic batches, exact diagnostics, export and versioned replay. |
| `shell-state.js`, `shell.js`, `shell.css` | Shared settings/navigation, learning preferences, display and update feedback. |
| `desktop.js`, `preload.js`, `main.js` | Sandboxed native host, fixed trusted IPC, fullscreen and update guards. |
| `build-info.js`, `scripts/sync-version.js`, `package.json` | Package-derived application version and native packaging. |

No files from the main Project Faction FPS project are needed or modified. Historical [Sprint 5](docs/SPRINT-005.md), [Sprint 4](docs/SPRINT-004.md) and [v0.5.0 release](docs/RELEASE-0.5.0.md) remain preserved.
